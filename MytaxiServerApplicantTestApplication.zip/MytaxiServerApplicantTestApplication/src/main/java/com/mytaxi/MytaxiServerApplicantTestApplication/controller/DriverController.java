package com.mytaxi.MytaxiServerApplicantTestApplication.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mytaxi.MytaxiServerApplicantTestApplication.dao.CarRepository;
import com.mytaxi.MytaxiServerApplicantTestApplication.exception.CarAlreadyInUseException;
import com.mytaxi.MytaxiServerApplicantTestApplication.exception.CarNotFoundException;
import com.mytaxi.MytaxiServerApplicantTestApplication.model.Car;


@RestController
public class DriverController {

	@Autowired
	private CarRepository carRepository;
	
	@GetMapping("/cars") //to find all cars 
	public List<Car> retrieveAllCars() {
		return carRepository.findAll();
	}
	
	@GetMapping("cars/{id}") //to find the particular car
	public Optional<Car> retrieveCarByID(@PathVariable Long id) {
		Optional<Car> car = carRepository.findById(id);

		if (!car.isPresent())
			throw new CarNotFoundException(String.format("Car ID-%s Not avaialble", id));
		return car;
	}
	
	@PostMapping("/cars") //to insert the car details
	public Optional<Car> createCar(@RequestBody Car car) {
		Car savedCar = carRepository.save(car);
		return carRepository.findById(savedCar.getId());
	}
	
	@PostMapping("/cars/{id}") //to update the driver detail when select or unselect the car
	public Optional<Car> updateCar(@PathVariable Long id, @RequestBody Car car) {
		
		Optional<Car> carid = carRepository.findById(id);

		if (!carid.isPresent())
			throw new CarNotFoundException(String.format("Car ID-%s Not avaialble", id));
		Car c=carid.get();
		//System.out.println("drivername-" + c.toString());
		if(!c.getDriver_name().equals("") && !car.getDriver_name().equals("")) {
			throw new CarAlreadyInUseException(String.format("Car ID-%s Already in use", id));
		}
		
		Car savedCar = carRepository.saveAndFlush(car);
		return carRepository.findById(savedCar.getId());
	}
	
	@DeleteMapping("/cars/{id}") // to delete the car detail
	public void deleteCar(@PathVariable Long id) {
		if (!carRepository.findById(id).isPresent())
			throw new CarNotFoundException(String.format("Car ID-%s Not avaialble", id));
		carRepository.deleteById(id);
	}
	
}
