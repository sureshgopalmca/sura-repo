insert into car values(10001,'yes',sysdate(),0,'Diesel','TN45 AC5478','Maruthi',5,4);
insert into car values(10002,'No',sysdate(),0,'Petrool','TN01 A4534','XYLO',5,7);
insert into car values(10003,'yes',sysdate(),0,'Diesel','TN23 DE1260','ENJOY',3,7);
insert into car values(10004,'No',sysdate(),0,'Petrool','TN63 AB6789','SWIFT',5,4);
insert into car values(10005,'yes',sysdate(),0,'Petrool','TN59 MN4534','FOARD',5,4);